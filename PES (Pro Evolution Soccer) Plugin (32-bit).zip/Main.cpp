#include "plugin.h"

using namespace plugin;

class $safeprojectname$ {
public:
    $safeprojectname$() {
        auto v = PES::GetAppVersion();
        switch (v.id()) {
        case ID_PES6:
            // Write code for PES 6 here
            break;
        case ID_PES5:
            // Write code for PES 5 and WE 9 here
            break;
        }
    }
} _$safeprojectname$;
